# Terminalis

Plataforma interativa para aprender **Linux, Bash e Docker** do zero ao nível de administração de servidores — sem vídeos, sem links externos, tudo escrito e praticável no próprio navegador.

O site inteiro é **um único arquivo HTML** (`dist/terminalis.html`), sem dependências externas em tempo de execução. Dentro dele roda um emulador de Linux escrito em JavaScript: sistema de arquivos com inodes e permissões reais, um interpretador Bash, processos, systemd, rede simulada e (em construção) uma engine de Docker.

## O que faz esse projeto ser diferente

- **Terminal de verdade, não uma caixa de texto que finge.** `mkdir` cria mesmo o diretório; `cd` muda mesmo de diretório; `chmod 700` faz o `cat` seguinte falhar com `Permission denied`.
- **Desafios verificados pelo estado do ambiente.** Cada desafio inspeciona o sistema de arquivos, a tabela de processos, os usuários, as portas — não a string que você digitou.
- **Auditoria automática dos desafios.** Todo verificador precisa passar em dois testes: reprovar um ambiente intocado *e* aprovar a solução oficial executada de verdade no emulador.
- **Sistema de dicas em três níveis** (dica leve → dica específica → solução), nunca revelado automaticamente.
- **Prática antiga × prática atual.** Quando um costume ficou para trás (`chmod -R 777` em `/var/www`, `nohup` como substituto de serviço, `limits.conf` para serviços do systemd), o curso diz o que era, o que se usa hoje e qual aprender.

## Estrutura

```
src/
  10-vfs.js            sistema de arquivos: inodes, modos, links, ACLs POSIX
  11-kernel.js         máquina: processos, systemd, journald, rede, /proc
  12-catalog.js        catálogo de pacotes e "internet" simulada
  20-shell-lex.js      tokenizer e parser do Bash
  21-shell-exec.js     expansões (parâmetro, aritmética, glob, substituição)
  22-shell-run.js      executor: pipelines, redirecionamentos, builtins, jobs
  30..33-*.js          ~175 comandos (coreutils, texto, admin, rede)
  50-content-*.js      estrutura do curso, trilhas e helpers de verificação
  5x-modNN.js          conteúdo dos módulos
  70-styles.css        identidade visual
  71-terminal.js       terminal (ANSI, histórico, Tab, Ctrl+C/D/Z, pager, nano)
  72-app.js            aplicação: rotas, progresso, trilhas, roadmap
  73-render.js         renderização dos blocos de conteúdo
  74-contas.js         contas locais + sincronização de progresso entre dispositivos
  75-shell.html        esqueleto da página
build.py               concatena tudo em dist/terminalis.html
test/
  smoke.js             testes do motor (101 asserções)
  solutions.js         auditoria dos desafios (executa cada solução oficial)
  ui.js                teste de interface com Playwright
```

## Como construir

```bash
python3 build.py          # gera dist/terminalis.html
node test/smoke.js        # testes do motor
node test/solutions.js    # auditoria dos desafios
node test/ui.js           # teste de interface (requer Playwright + Chromium)
```

Não há dependências de build: o `build.py` só concatena os arquivos de `src/` na ordem alfabética e injeta o CSS no HTML.

## Estado atual

| Trilha | Módulos | Situação |
|---|---|---|
| Linux | 1–16 | 1 a 7 publicados |
| Docker | 17–24 | engine em construção |
| Troubleshooting e projetos | 25–26 | planejados |

Trilhas futuras previstas na interface: Git, Python para automação, Redes, SQL e Kubernetes.

## Licença

Uso pessoal e educacional.
