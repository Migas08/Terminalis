/* Testa a plataforma em navegador headless */
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage({ viewport: { width: 1536, height: 1000 } });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text()); });

  await page.goto('file://' + path.join(__dirname, '..', 'dist', 'terminalis.html'));
  await page.waitForTimeout(900);

  const boot = await page.evaluate(() => ({
    app: !!window.__app,
    mods: window.LX && LX.COURSE ? LX.COURSE.modules.length : -1,
    lessons: window.LX && LX.COURSE ? LX.COURSE.modules.reduce((s, m) => s + m.lessons.length, 0) : -1,
    railHtml: document.getElementById('rail-nav').innerHTML.length,
    pageHtml: document.getElementById('page').innerHTML.length
  }));
  console.log('boot:', JSON.stringify(boot));

  // abre a primeira aula
  await page.evaluate(() => window.__app.goLesson('l1-1'));
  await page.waitForTimeout(400);
  const title = await page.textContent('h1.title');
  console.log('aula:', title);

  // executa comandos no terminal
  const runTerm = async (cmd) => await page.evaluate(async (c) => {
    await window.__app.term.runVisible(c);
    return document.getElementById('term-out').innerText.slice(-500);
  }, cmd);

  console.log('--- ls ---');
  console.log(await runTerm('ls'));
  console.log('--- pwd + uname ---');
  console.log(await runTerm('pwd && uname -r'));

  // verifica desafio 1.1-a
  const v1 = await page.evaluate(async () => {
    await window.__app.term.runVisible('uname -r');
    await window.__app.term.runVisible('cat /etc/os-release');
    await window.__app.term.runVisible('hostname');
    const t = window.__app.taskById('t1-1-a');
    return await t.check({ app: __app, machine: __app.machine, term: __app.term, sh: __app.term.sh });
  });
  console.log('check t1-1-a:', JSON.stringify(v1));

  const v2 = await page.evaluate(async () => {
    await window.__app.term.runVisible('uname -r > ~/sistema.txt');
    await window.__app.term.runVisible('grep PRETTY_NAME /etc/os-release >> ~/sistema.txt');
    await window.__app.term.runVisible('hostname >> ~/sistema.txt');
    const t = window.__app.taskById('t1-1-b');
    return await t.check({ app: __app, machine: __app.machine, term: __app.term, sh: __app.term.sh });
  });
  console.log('check t1-1-b:', JSON.stringify(v2));

  // aba arquivos
  await page.evaluate(() => window.__app.switchTab('files'));
  await page.waitForTimeout(300);
  const files = await page.evaluate(() => document.getElementById('fb-list').innerText.split('\n').slice(0, 6));
  console.log('arquivos:', JSON.stringify(files));
  await page.evaluate(() => window.__app.switchTab('term'));

  await page.screenshot({ path: path.join(__dirname, 'shot-lesson.png') });
  await page.evaluate(() => window.__app.goRoadmap());
  await page.waitForTimeout(300);
  await page.screenshot({ path: path.join(__dirname, 'shot-roadmap.png') });

  await page.setViewportSize({ width: 420, height: 860 });
  await page.evaluate(() => window.__app.goLesson('l1-2'));
  await page.waitForTimeout(300);
  await page.screenshot({ path: path.join(__dirname, 'shot-mobile.png') });


  // contas
  const contas = await page.evaluate(() => {
    const C = LX.Contas;
    const antes = C.perfis.length;
    C.criar('Maria');
    const codigo = C.exportar();
    const chaveMaria = C.ativo().chave;
    C.trocar(C.perfis[0].id);
    const r = C.importar(codigo);
    return { antes, depois: C.perfis.length, chaveMaria, importou: r, ativo: C.ativo().nome, estado: C.estado };
  });
  console.log('contas:', JSON.stringify(contas));
  await page.evaluate(() => { document.getElementById('conta-chip').click(); });
  await page.waitForTimeout(200);
  const menuLen = await page.evaluate(() => document.getElementById('conta-menu').innerHTML.length);
  console.log('menu de conta html:', menuLen);
  await page.setViewportSize({ width: 1536, height: 1000 });
  await page.screenshot({ path: require('path').join(__dirname, 'shot-contas.png') });

  console.log('\nerros:', errors.length);
  errors.slice(0, 12).forEach(e => console.log('  ' + e));
  await browser.close();
  process.exit(errors.length ? 1 : 0);
})();
