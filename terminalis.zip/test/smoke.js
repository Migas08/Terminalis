const { loadEngine, makeSession } = require('./harness');

const LX = loadEngine();
console.log('Motor carregado. Comandos registrados:', Object.keys(LX.COMMANDS).length);

let pass = 0, fail = 0;
const failures = [];

function check(name, actual, expected) {
  const ok = typeof expected === 'function' ? expected(actual) : String(actual).trim() === String(expected).trim();
  if (ok) pass++;
  else { fail++; failures.push({ name, actual: String(actual).slice(0, 400), expected: typeof expected === 'function' ? '(predicado)' : expected }); }
}

(async () => {
  const s = makeSession(LX);

  const T = async (cmd, expected, label) => {
    let r;
    try { r = await s.run(cmd); }
    catch (e) { fail++; failures.push({ name: label || cmd, actual: 'EXCEÇÃO: ' + e.message + '\n' + (e.stack || '').split('\n').slice(1, 3).join('\n'), expected: 'sem exceção' }); return; }
    check(label || cmd, r.out, expected);
  };

  // básicos
  await T('pwd', '/home/aluno');
  await T('echo ola mundo', 'ola mundo');
  await T('echo "aspas    preservam   espaco"', 'aspas    preservam   espaco');
  await T("echo 'sem $EXPANSAO'", 'sem $EXPANSAO');
  await T('echo $HOME', '/home/aluno');
  await T('echo ${HOME}/docs', '/home/aluno/docs');
  await T('echo $((2 + 3 * 4))', '14');
  await T('echo $((10 / 3))', '3');
  await T('echo {a,b,c}', 'a b c');
  await T('echo {1..5}', '1 2 3 4 5');
  await T('echo arq{01..03}.txt', 'arq01.txt arq02.txt arq03.txt');
  await T('echo $(echo aninhado)', 'aninhado');
  await T('X=10; echo $X', '10');
  await T('X=abc; echo ${#X}', '3');
  await T('f=/tmp/a/b.txt; echo ${f##*/}', 'b.txt');
  await T('f=/tmp/a/b.txt; echo ${f%.*}', '/tmp/a/b');
  await T('v=Ola; echo ${v:-padrao}; unset v; echo ${v:-padrao}', 'Ola\npadrao');
  await T('echo ${NAODEFINIDA:-vazio}', 'vazio');
  await T('s=banana; echo ${s//a/o}', 'bonono');
  await T('echo ${s:2:3}', o => true);

  // fs
  await T('mkdir -p proj/src proj/docs && ls proj | cat', 'docs\nsrc');
  await T('touch proj/src/main.sh && ls proj/src', 'main.sh');
  await T('cd proj && pwd', '/home/aluno/proj');
  await T('cd .. && pwd', '/home/aluno');
  await T('echo linha1 > f.txt; echo linha2 >> f.txt; cat f.txt', 'linha1\nlinha2');
  await T('wc -l < f.txt', '2');
  await T('cat f.txt | wc -l', '2');
  await T('ls naoexiste 2>&1', o => /No such file or directory/.test(o));
  await T('ls naoexiste 2>/dev/null; echo $?', '2');
  await T('cp f.txt g.txt && diff f.txt g.txt; echo $?', '0');
  await T('rm g.txt && ls g.txt 2>&1 | head -1', o => /No such file/.test(o));

  // pipes e filtros
  await T('printf "c\\nb\\na\\n" | sort', 'a\nb\nc');
  await T('printf "1\\n2\\n2\\n3\\n" | uniq -c | tr -s " "', ' 1 1\n 2 2\n 1 3');
  await T('printf "a:1\\nb:2\\n" | cut -d: -f2', '1\n2');
  await T('echo "ola mundo" | tr a-z A-Z', 'OLA MUNDO');
  await T('printf "um\\ndois\\ntres\\n" | grep -n do', '2:dois');
  await T('printf "um\\ndois\\n" | grep -c .', '2');
  await T('printf "x=1\\ny=2\\n" | sed "s/=/ vale /"', 'x vale 1\ny vale 2');
  await T('printf "a\\nb\\nc\\n" | sed -n 2p', 'b');
  await T('printf "a\\nb\\nc\\n" | sed "2d"', 'a\nc');
  await T('printf "1 2\\n3 4\\n" | awk "{print \\$2}"', '2\n4');
  await T(`printf "1 2\\n3 4\\n" | awk '{s+=$1} END {print s}'`, '4');
  await T(`awk 'BEGIN{printf "%05.2f\\n", 3.14159}'`, '03.14');
  await T(`printf "ana,30\\nbia,25\\n" | awk -F, '$2>26 {print $1}'`, 'ana');
  await T(`echo "a b c" | awk '{print NF}'`, '3');

  // condicionais e loops
  await T('if [ 1 -lt 2 ]; then echo sim; else echo nao; fi', 'sim');
  await T('for i in 1 2 3; do echo -n $i; done; echo', '123');
  await T('for ((i=0;i<3;i++)); do echo -n $i; done; echo', '012');
  await T('i=0; while [ $i -lt 3 ]; do echo -n $i; i=$((i+1)); done; echo', '012');
  await T('case abc in a*) echo casou;; *) echo nao;; esac', 'casou');
  await T('f() { echo "arg=$1"; }; f teste', 'arg=teste');
  await T('f() { return 3; }; f; echo $?', '3');
  await T('[[ "abc" == a* ]] && echo glob-ok', 'glob-ok');
  await T('[[ "abc" =~ ^a.c$ ]] && echo regex-ok', 'regex-ok');
  await T('true && echo A || echo B', 'A');
  await T('false && echo A || echo B', 'B');
  await T('a=(um dois tres); echo ${a[1]} ${#a[@]}', 'dois 3');
  await T('a=(x y z); for v in "${a[@]}"; do echo -n $v-; done; echo', 'x-y-z-');

  // permissões
  await T('touch p.sh && chmod 755 p.sh && ls -l p.sh | cut -d" " -f1', '-rwxr-xr-x');
  await T('chmod u-w p.sh && ls -l p.sh | cut -d" " -f1', '-r-xr-xr-x');
  await T('chmod +w p.sh && ls -l p.sh | cut -d" " -f1', '-rwxrwxrwx');
  await T('umask', '0022');
  await T('id -u', '1000');
  await T('whoami', 'aluno');

  // scripts
  await T(`printf '#!/bin/bash\\necho "rodou com $1"\\n' > s.sh; chmod +x s.sh; ./s.sh xyz`, 'rodou com xyz');
  await T(`chmod -x s.sh; ./s.sh 2>&1`, o => /Permission denied/.test(o));
  await T(`cat > h.sh << 'EOF'
#!/bin/bash
for f in a b; do
  echo "item: $f"
done
EOF
bash h.sh`, 'item: a\nitem: b');

  // processos / sistema
  await T('ps | head -1', o => /PID/.test(o));
  await T('uname -s', 'Linux');
  await T('cat /etc/os-release | grep VERSION_ID', 'VERSION_ID="26.04"');
  await T('grep -c . /etc/passwd', o => +o.trim() >= 10);
  await T('sudo whoami', 'root');
  await T('systemctl is-active ssh', 'active');
  await T('df -h / | tail -1 | awk "{print \\$6}"', '/');
  await T('free -m | head -1', o => /total/.test(o));

  // rede
  await T('ip -br a | head -1', o => /lo/.test(o));
  await T('ss -tlnp | grep -c 22', o => +o.trim() >= 1);
  await T('curl -s http://terminalis.dev/api/status', o => /"status":"ok"/.test(o));
  await T('curl -s http://localhost:9999 2>&1; echo "rc=$?"', o => /rc=7/.test(o));
  await T('dig +short example.com', '93.184.216.34');

  // pacotes
  await T('apt list --installed 2>/dev/null | grep -c bash', o => +o.trim() >= 1);
  await T('sudo apt install -y tree > /dev/null 2>&1; which tree', '/usr/bin/tree');
  await T('tree -L 1 /home', o => /aluno/.test(o));

  // find / xargs
  await T('mkdir -p t1/t2 && touch t1/a.log t1/t2/b.log && find t1 -name "*.log" | sort', 't1/a.log\nt1/t2/b.log');
  await T('find t1 -type d | sort', 't1\nt1/t2');
  await T('find t1 -name "*.log" | xargs -n1 basename | sort', 'a.log\nb.log');

  // tar
  await T('tar -czf t1.tar.gz t1 && tar -tzf t1.tar.gz | head -1', 't1/');
  await T('mkdir -p out && tar -xzf t1.tar.gz -C out && ls out/t1 | cat', 'a.log\nt2');

  // atribuições com aspas (NOME="Ana Maria")
  await T('NOME="Ana Maria"; echo "[$NOME]"', '[Ana Maria]');
  await T('MSG=\'um dois\'; echo "$MSG"', 'um dois');
  await T('A=1; A+=" 2"; echo "$A"', '1 2');
  await T('false | true; ST="${PIPESTATUS[@]}"; echo "$ST"', '1 0');
  await T('D="$(echo oi)"; echo "$D"', 'oi');
  await T('P="/tmp"; cd "$P" && pwd', '/tmp');

  // find: expressões com -o e parênteses
  await T('mkdir -p ex && touch ex/a.txt ex/b.log && find ex \\( -name "*.txt" -o -name "*.log" \\) -type f | sort', 'ex/a.txt\nex/b.log');
  await T('find ex -name "*.txt" ! -name "b*" | sort', 'ex/a.txt');
  await T('sudo -u root whoami > /tmp/rr.txt; cat /tmp/rr.txt', 'root');
  await T('setfacl -m u:root:rw ex/a.txt && getfacl ex/a.txt | grep -c "user:root"', '1');
  await T('ls -l ex/a.txt | cut -c1-11', '-rw-rw-r--+');
  await T('setfacl -b ex/a.txt && ls -l ex/a.txt | cut -c1-11', '-rw-r--r--');
  await T('namei -l /etc/passwd | tail -1 | awk \'{print $1, $NF}\'', '-rw-r--r-- passwd');

  console.log(`\n=== ${pass} passaram, ${fail} falharam ===`);
  if (failures.length) {
    for (const f of failures.slice(0, 40)) {
      console.log(`\n✗ ${f.name}\n   esperado: ${JSON.stringify(f.expected)}\n   obtido:   ${JSON.stringify(f.actual)}`);
    }
  }
  process.exit(fail ? 1 : 0);
})();
