/* =========================================================================
   TERMINALIS — mapa dos módulos
   ========================================================================= */
'use strict';
(function () {
  const L = 'Linux', D = 'Docker', P = 'Projeto final';

  const M = [
    ['m01', '01', L, 'Fundamentos', 'Kernel, distribuição, shell e a lógica do sistema de arquivos.'],
    ['m02', '02', L, 'Terminal e comandos básicos', 'Navegar, criar, copiar, mover, apagar e ler arquivos.'],
    ['m03', '03', L, 'Texto e busca', 'grep, find, sort, cut, tr, sed e awk — encontrar e transformar.'],
    ['m04', '04', L, 'Pipes e redirecionamentos', 'stdin, stdout, stderr e como os comandos se encaixam.'],
    ['m05', '05', L, 'Permissões', 'rwx, octal, dono, grupo, sudo, SUID, SGID e sticky bit.'],
    ['m06', '06', L, 'Usuários e grupos', '/etc/passwd, /etc/shadow, criação e administração de contas.'],
    ['m07', '07', L, 'Processos', 'PID, sinais, primeiro e segundo plano, ps, top e kill.'],
    ['m08', '08', L, 'Serviços e systemd', 'systemctl, journalctl, unidades, boot e diagnóstico.'],
    ['m09', '09', L, 'Redes', 'IP, CIDR, DNS, portas, TCP/UDP e as ferramentas do iproute2.'],
    ['m10', '10', L, 'SSH', 'Chaves, agente, config, scp e rsync — acesso remoto com segurança.'],
    ['m11', '11', L, 'Armazenamento', 'Discos, partições, filesystems, inodes, montagem e fstab.'],
    ['m12', '12', L, 'Pacotes', 'apt e dpkg: instalar, remover, investigar e manter repositórios.'],
    ['m13', '13', L, 'Compactação e arquivos', 'tar, gzip, zip — empacotar, transferir e restaurar.'],
    ['m14', '14', L, 'Variáveis e ambiente', 'PATH, HOME, export, .bashrc e o que o shell carrega.'],
    ['m15', '15', L, 'Bash scripting', 'Do shebang à automação com funções, testes e tratamento de erro.'],
    ['m16', '16', L, 'Administração de servidores', 'Rotina real: logs, monitoramento, firewall, backup e segurança.'],
    ['m17', '17', D, 'Fundamentos do Docker', 'Imagens, containers, daemon, registry e o que muda em relação a VMs.'],
    ['m18', '18', D, 'Comandos do Docker', 'O ciclo de vida completo de um container, comando por comando.'],
    ['m19', '19', D, 'docker run e suas flags', 'Por que cada flag existe e o que ela realmente faz.'],
    ['m20', '20', D, 'Dockerfile', 'Camadas, cache, contexto, multi-stage e boas práticas de build.'],
    ['m21', '21', D, 'Volumes', 'Bind mounts, volumes nomeados, tmpfs, permissões e backup.'],
    ['m22', '22', D, 'Networks', 'Bridge, host, none, DNS interno e comunicação entre containers.'],
    ['m23', '23', D, 'Docker Compose', 'compose.yaml, dependências, healthchecks e ambientes completos.'],
    ['m24', '24', D, 'Docker avançado', 'Segurança, limites, healthcheck, secrets e Docker em produção.'],
    ['m25', '25', P, 'Troubleshooting', 'Método de diagnóstico para Linux e Docker, com ambientes quebrados.'],
    ['m26', '26', P, 'Projetos', 'Nove projetos progressivos e o projeto final integrado.']
  ];

  for (const [id, num, group, title, blurb] of M) {
    LX.mod({ id, num, group, title, blurb });
  }
})();
