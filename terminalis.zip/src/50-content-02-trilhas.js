/* =========================================================================
   TERMINALIS — trilhas de aprendizado
   A plataforma é multi-trilha: hoje Linux e Docker, com espaço para
   novas trilhas sem mexer na estrutura.
   ========================================================================= */
'use strict';
(function () {

  const SVG = {
    linux: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 18.5c0-2 1.2-3.2 1.2-5.4C6.2 8.4 8 4 12 4s5.8 4.4 5.8 9.1c0 2.2 1.2 3.4 1.2 5.4 0 1.4-1.6 2-3.2 1.4-1 1-2.5 1.1-3.8 1.1s-2.8-.1-3.8-1.1C6.6 20.5 5 19.9 5 18.5z"/><circle cx="10.2" cy="10" r="1.1" fill="currentColor" stroke="none"/><circle cx="13.8" cy="10" r="1.1" fill="currentColor" stroke="none"/><path d="M10.6 13.3c.5.6 2.3.6 2.8 0"/></svg>',
    docker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><rect x="3" y="11" width="3" height="3"/><rect x="6.5" y="11" width="3" height="3"/><rect x="10" y="11" width="3" height="3"/><rect x="13.5" y="11" width="3" height="3"/><rect x="6.5" y="7.6" width="3" height="3"/><rect x="10" y="7.6" width="3" height="3"/><rect x="10" y="4.2" width="3" height="3"/><path d="M2 15.5c0 3 2.4 4.8 6.4 4.8 5.6 0 9.4-2.6 10.6-6.6 1.4.5 2.6.2 3-1.2-1-.7-2.4-.7-3.4-.2"/></svg>',
    wrench: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 3.5a5 5 0 0 0-5.9 6.6L3.6 16a2 2 0 1 0 2.8 2.8l5.9-5.9a5 5 0 0 0 6.6-5.9l-2.8 2.8-2.5-.7-.7-2.5z"/></svg>',
    git: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="6.5" cy="6" r="2.2"/><circle cx="6.5" cy="18" r="2.2"/><circle cx="17.5" cy="9" r="2.2"/><path d="M6.5 8.2v7.6M8.7 6.6c3.5.6 6.6 1 6.6 2.4M17.5 11.2c0 4.4-4.2 3.6-8.8 5.6"/></svg>',
    python: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M12 3c-3 0-4 1.2-4 3v2h4.5v.8H6.5C4.6 8.8 3.5 10 3.5 13s1 4.2 2.5 4.2H8v-2.4c0-1.8 1.4-3.2 3.2-3.2h3.6c1.5 0 2.7-1.2 2.7-2.7V6C17.5 4.2 15.5 3 12 3z"/><path d="M12 21c3 0 4-1.2 4-3v-2h-4.5v-.8h6c1.9 0 3-1.2 3-4.2s-1-4.2-2.5-4.2H16v2.4c0 1.8-1.4 3.2-3.2 3.2H9.2c-1.5 0-2.7 1.2-2.7 2.7V18c0 1.8 2 3 5.5 3z"/></svg>',
    net: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 2.6 15 0 18M12 3c-2.6 2.6-2.6 15 0 18"/></svg>',
    db: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6"/><path d="M4.5 12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3"/></svg>',
    k8s: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M12 2.6l8 3.8v7.2l-8 3.8-8-3.8V6.4z"/><circle cx="12" cy="10" r="2.4"/><path d="M12 2.6V7.6M19.2 6.9l-4.9 2.2M4.8 6.9l4.9 2.2M12 12.4v5.2M6 13.6l4.2-2M18 13.6l-4.2-2"/></svg>'
  };

  LX.TRILHAS = [
    {
      id: 'linux', nome: 'Linux e o terminal', icone: SVG.linux, cor: 'amber',
      resumo: 'Do primeiro comando à administração de um servidor de produção.',
      detalhe: 'Fundamentos, arquivos, texto, pipes, permissões, usuários, processos, serviços, redes, SSH, armazenamento, pacotes, ambiente, Bash scripting e administração.',
      nivel: 'Iniciante → avançado',
      mods: ['m01', 'm02', 'm03', 'm04', 'm05', 'm06', 'm07', 'm08', 'm09', 'm10', 'm11', 'm12', 'm13', 'm14', 'm15', 'm16'],
      estado: 'disponivel'
    },
    {
      id: 'docker', nome: 'Docker na prática', icone: SVG.docker, cor: 'blue',
      resumo: 'Containers, imagens, volumes, redes e Compose — construindo ambientes reais.',
      detalhe: 'Fundamentos, ciclo de vida dos containers, flags do run, Dockerfile e camadas, volumes, networks, Docker Compose e tópicos avançados de segurança e produção.',
      nivel: 'Requer o básico de Linux',
      mods: ['m17', 'm18', 'm19', 'm20', 'm21', 'm22', 'm23', 'm24'],
      estado: 'disponivel'
    },
    {
      id: 'ops', nome: 'Troubleshooting e projetos', icone: SVG.wrench, cor: 'red',
      resumo: 'Ambientes quebrados para você investigar, e projetos que integram tudo.',
      detalhe: 'Método de diagnóstico para Linux e Docker, cenários reais de falha e nove projetos progressivos até o projeto final.',
      nivel: 'Depois de Linux e Docker',
      mods: ['m25', 'm26'],
      estado: 'disponivel'
    },
    { id: 'git', nome: 'Git e fluxo de trabalho', icone: SVG.git, cor: 'amber', resumo: 'Versionamento, branches, merge, rebase e trabalho em equipe.', estado: 'planejado' },
    { id: 'py', nome: 'Python para automação', icone: SVG.python, cor: 'blue', resumo: 'Scripts que substituem tarefas repetitivas de infraestrutura.', estado: 'planejado' },
    { id: 'redes', nome: 'Redes para quem opera', icone: SVG.net, cor: 'green', resumo: 'TCP/IP, DNS, TLS, proxies reversos e diagnóstico de conectividade.', estado: 'planejado' },
    { id: 'sql', nome: 'SQL e bancos de dados', icone: SVG.db, cor: 'violet', resumo: 'Consultas, índices, backup e restauração no dia a dia de operação.', estado: 'planejado' },
    { id: 'k8s', nome: 'Kubernetes', icone: SVG.k8s, cor: 'blue', resumo: 'Pods, deployments, services e o passo seguinte ao Docker.', estado: 'planejado' }
  ];

  LX.trilhaDe = function (modId) {
    return LX.TRILHAS.find(t => (t.mods || []).includes(modId)) || null;
  };
  LX.trilhaPorId = function (id) { return LX.TRILHAS.find(t => t.id === id) || null; };
})();
