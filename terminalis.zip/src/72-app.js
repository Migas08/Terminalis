/* =========================================================================
   TERMINALIS — aplicação: navegação, progresso, desafios
   ========================================================================= */
'use strict';
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const ICON = {
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5" fill="currentColor" stroke="none" opacity=".18"/><circle cx="12" cy="12" r="9.5"/><path d="M8 12.4l2.6 2.6L16 9.6"/></svg>',
    ring: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="12" r="3.2" fill="currentColor" stroke="none"/></svg>',
    circle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>',
    terminal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17l6-5-6-5"/><path d="M12 19h8"/></svg>',
    files: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
    notes: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
    folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M7 4.5v15l13-7.5z"/></svg>',
    prev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    next: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
    reset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    map: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4L3 6.5v13L9 17l6 3 6-2.5v-13L15 7z"/><path d="M9 4v13M15 7v13"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/></svg>',
    bulb: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"/><path d="M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5.9 1.2.9 1.9v.2h5.2v-.2c0-.7.3-1.4.9-1.9A6 6 0 0 0 12 3z"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="2.8"/></svg>',
    verify: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 6.5"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    trophy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 5H5v2a3 3 0 0 0 3 3M16 5h3v2a3 3 0 0 1-3 3"/><path d="M10 13v3h4v-3M8 20h8"/></svg>',
    help: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .9-1 1.6v.3"/><path d="M12 17h.01"/></svg>'
  };
  LX.ICON = ICON;

  /* ============================== progresso ============================== */
  const VAZIO = () => ({ lessons: {}, tasks: {}, notes: {}, seconds: 0, lastLesson: null, streakDays: [], atualizadoEm: 0 });
  const Progress = {
    data: VAZIO(),
    load() {
      if (LX.Contas && LX.Contas.ativoId) this.data = LX.Contas.lerProgresso(LX.Contas.ativoId);
      return this.data;
    },
    replace(d) { this.data = Object.assign(VAZIO(), d || {}); return this.data; },
    save() {
      this.data.atualizadoEm = Date.now();
      if (LX.Contas && LX.Contas.ativoId) {
        LX.Contas.gravarProgresso(LX.Contas.ativoId, this.data);
        LX.Contas.agendarEnvio(this.data);
      }
    },
    lessonDone(id) { return !!this.data.lessons[id]; },
    markLesson(id, v) { if (v) this.data.lessons[id] = Date.now(); else delete this.data.lessons[id]; this.save(); },
    taskDone(id) { return !!this.data.tasks[id]; },
    markTask(id) { if (!this.data.tasks[id]) { this.data.tasks[id] = Date.now(); this.save(); return true; } return false; },
    reset() { this.data = VAZIO(); this.save(); }
  };
  LX.Progress = Progress;

  /* ============================== aplicação ============================== */
  class App {
    constructor() {
      this.course = LX.COURSE;
      this.route = { view: 'home', mod: null, lesson: null };
      this.trilhaId = null;
      this.openMods = new Set();
      this.sessionStart = Date.now();
    }

    start() {
      if (LX.Contas) LX.Contas.montar(this);
      Progress.load();
      this.buildMachine();
      this.term = new LX.Terminal(document.getElementById('side-panel'), this);
      this.term.boot(this.machine);
      this.bindChrome();
      this.renderRail();
      this.startClock();
      try { this.trilhaId = localStorage.getItem('terminalis.trilha') || null; } catch (e) { }
      const last = Progress.data.lastLesson;
      if (last && this.findLesson(last)) { this.trilhaId = (LX.trilhaDe(this.findLesson(last).mod.id) || {}).id || this.trilhaId; this.goLesson(last); }
      else if (this.trilhaId && LX.trilhaPorId(this.trilhaId)) this.goRoadmap();
      else this.goHome();
      this.term.focus();
    }

    buildMachine() {
      this.machine = new LX.Machine();
      LX.installBinaries(this.machine);
      if (LX.DockerEngine) this.machine.docker = new LX.DockerEngine(this.machine);
      // cenário base de arquivos para os primeiros módulos
      if (LX.seedWorkspace) LX.seedWorkspace(this.machine);
    }

    resetEnvironment() {
      if (!confirm('Recriar a máquina do zero? Os arquivos que você criou no terminal serão perdidos (seu progresso nas aulas é mantido).')) return;
      this.buildMachine();
      this.term.boot(this.machine);
      this.toast('Ambiente reiniciado');
      if (this.route.view === 'lesson') this.applyLessonSetup();
    }

    /* Recebe um progresso novo (troca de perfil ou sincronização) */
    recarregarProgresso(dados) {
      Progress.replace(dados);
      this.renderRail();
      if (this.route.view === 'lesson' && this.findLesson(this.route.lesson)) this.goLesson(this.route.lesson);
      else if (this.route.view === 'roadmap') this.renderRoadmap();
    }

    /* ----------------------------- estrutura ----------------------------- */
    trilha() { return this.trilhaId ? LX.trilhaPorId(this.trilhaId) : null; }
    modulosDaTrilha() {
      const t = this.trilha();
      if (!t) return this.course.modules;
      return this.course.modules.filter(m => (t.mods || []).includes(m.id));
    }
    allLessons() {
      const out = [];
      for (const m of this.modulosDaTrilha()) for (const l of m.lessons) out.push({ mod: m, lesson: l });
      return out;
    }
    todasAsLicoes() {
      const out = [];
      for (const m of this.course.modules) for (const l of m.lessons) out.push({ mod: m, lesson: l });
      return out;
    }
    statsTrilha(t) {
      const mods = this.course.modules.filter(m => (t.mods || []).includes(m.id));
      const licoes = mods.flatMap(m => m.lessons);
      const feitas = licoes.filter(l => Progress.lessonDone(l.id)).length;
      return { mods: mods.length, licoes: licoes.length, feitas, pct: licoes.length ? Math.round(feitas / licoes.length * 100) : 0 };
    }
    findLesson(id) { return this.todasAsLicoes().find(x => x.lesson.id === id) || null; }
    lessonIndex(id) { return this.allLessons().findIndex(x => x.lesson.id === id); }

    stats() {
      const all = this.allLessons();
      const done = all.filter(x => Progress.lessonDone(x.lesson.id)).length;
      const tasks = Object.keys(Progress.data.tasks).length;
      let totalTasks = 0;
      for (const { lesson } of all) totalTasks += (lesson.tasks || []).length;
      const modsDone = this.course.modules.filter(m => m.lessons.length && m.lessons.every(l => Progress.lessonDone(l.id))).length;
      return { total: all.length, done, pct: all.length ? Math.round(done / all.length * 100) : 0, tasks, totalTasks, modsDone, totalMods: this.course.modules.length };
    }

    /* ----------------------------- chrome ----------------------------- */
    bindChrome() {
      $('#rail-toggle').onclick = () => document.body.classList.toggle('rail-open');
      document.addEventListener('click', (e) => {
        if (document.body.classList.contains('rail-open') && !e.target.closest('#rail') && !e.target.closest('#rail-toggle'))
          document.body.classList.remove('rail-open');
      });
      $('#btn-roadmap').onclick = () => { if (this.trilha()) this.goRoadmap(); else this.goHome(); };
      $('#brand').onclick = () => this.goHome();
      $('#rail-help').onclick = () => this.goPage('ajuda');
      $$('.sp-tab').forEach(t => t.onclick = () => this.switchTab(t.dataset.tab));
      $('#btn-reset-term').onclick = () => this.resetEnvironment();
      $('#btn-new-term').onclick = () => { this.term.clear(); this.term.prompt(); this.term.focus(); };
      $$('.mobile-tabs button').forEach(b => b.onclick = () => {
        const t = b.dataset.m;
        document.body.classList.toggle('show-term', t === 'term');
        $$('.mobile-tabs button').forEach(x => x.setAttribute('aria-pressed', String(x.dataset.m === t)));
        if (t === 'term') this.term.focus();
      });
      const notes = $('#notes-area');
      notes.addEventListener('input', () => {
        const key = this.route.lesson || '_geral';
        Progress.data.notes[key] = notes.value;
        Progress.save();
        $('#notes-status').textContent = 'salvo';
        clearTimeout(this._nt);
        this._nt = setTimeout(() => { $('#notes-status').textContent = 'salvo automaticamente'; }, 1200);
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && document.body.classList.contains('rail-open')) document.body.classList.remove('rail-open');
        if ((e.ctrlKey || e.metaKey) && e.key === '`') { e.preventDefault(); this.switchTab('term'); this.term.focus(); }
      });
    }

    switchTab(tab) {
      $$('.sp-tab').forEach(t => t.setAttribute('aria-selected', String(t.dataset.tab === tab)));
      $$('.sp-view').forEach(v => v.classList.toggle('active', v.dataset.view === tab));
      $('#sp-term-actions').classList.toggle('hidden', tab !== 'term');
      $('#sp-file-actions').classList.toggle('hidden', tab !== 'files');
      if (tab === 'files') this.renderFiles();
      if (tab === 'notes') {
        const key = this.route.lesson || '_geral';
        $('#notes-area').value = Progress.data.notes[key] || '';
        $('#notes-title').textContent = this.route.lesson ? (this.findLesson(this.route.lesson).lesson.title) : 'Anotações gerais';
      }
      if (tab === 'term') this.term.focus();
    }

    startClock() {
      const el = $('#term-clock');
      setInterval(() => {
        const s = Math.floor((Date.now() - this.sessionStart) / 1000) + (Progress.data.seconds || 0);
        const h = String(Math.floor(s / 3600)).padStart(2, '0');
        const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
        const ss = String(s % 60).padStart(2, '0');
        el.textContent = `${h}:${m}:${ss}`;
      }, 1000);
      setInterval(() => {
        Progress.data.seconds = (Progress.data.seconds || 0) + 30;
        this.sessionStart = Date.now();
        const today = new Date().toISOString().slice(0, 10);
        if (!Progress.data.streakDays.includes(today)) Progress.data.streakDays.push(today);
        Progress.save();
      }, 30000);
    }

    toast(msg) {
      const t = document.createElement('div');
      t.className = 'toast';
      t.innerHTML = `<span class="ic">${ICON.check}</span>${esc(msg)}`;
      document.body.appendChild(t);
      setTimeout(() => t.remove(), 2400);
    }

    /* ----------------------------- trilho ----------------------------- */
    renderRail() {
      const st = this.stats();
      $('#rail-pct').textContent = st.pct + '%';
      $('#rail-bar').style.width = st.pct + '%';
      $('#rail-sub').textContent = `${st.done} de ${st.total} aulas concluídas`;
      $('#achv-count').textContent = st.tasks;

      const nav = $('#rail-nav');
      const t = this.trilha();
      const cabecalho = t
        ? `<button class="trilha-back" id="trilha-back">${ICON.prev}<span>Todas as trilhas</span></button>
           <div class="trilha-atual"><span class="ic c-${t.cor}">${t.icone}</span><span class="nm">${esc(t.nome)}</span></div>`
        : '';
      let html = cabecalho;
      let lastGroup = null;
      for (const m of this.modulosDaTrilha()) {
        if (m.group !== lastGroup) { html += `<div class="grp-label">${esc(m.group)}</div>`; lastGroup = m.group; }
        const done = m.lessons.filter(l => Progress.lessonDone(l.id)).length;
        const isOpen = this.openMods.has(m.id);
        const isCur = this.route.mod === m.id;
        html += `<button class="mod ${isOpen ? 'open' : ''} ${done === m.lessons.length && m.lessons.length ? 'full' : ''}" data-mod="${m.id}" aria-current="${isCur}">
          <span class="caret">▶</span>
          <span>${esc(m.title)}</span>
          <span class="cnt">${m.lessons.length ? done + '/' + m.lessons.length : 'em breve'}</span>
        </button>`;
        html += `<div class="lessons">`;
        for (const l of m.lessons) {
          const d = Progress.lessonDone(l.id);
          const cur = this.route.lesson === l.id;
          const state = d ? 'done' : (cur ? 'cur' : 'todo');
          const ic = d ? ICON.check : (cur ? ICON.ring : ICON.circle);
          html += `<button class="lesson-link" data-lesson="${l.id}" aria-current="${cur}">
            <span class="dot-state ${state}">${ic}</span>
            <span>${esc(l.n)} ${esc(l.title)}</span>
          </button>`;
        }
        html += `</div>`;
      }
      nav.innerHTML = html;
      const back = $('#trilha-back', nav);
      if (back) back.onclick = () => this.goHome();
      $$('.mod', nav).forEach(b => b.onclick = () => {
        const id = b.dataset.mod;
        if (this.openMods.has(id)) this.openMods.delete(id); else this.openMods.add(id);
        this.renderRail();
      });
      $$('.lesson-link', nav).forEach(b => b.onclick = () => {
        this.goLesson(b.dataset.lesson);
        document.body.classList.remove('rail-open');
      });
    }

    setCrumbs(a, b) {
      $('#crumb-1').textContent = a;
      $('#crumb-2').textContent = b;
      $('#mobile-now').textContent = b;
    }

    /* ----------------------------- roteamento ----------------------------- */
    goHome() {
      this.route = { view: 'home', mod: null, lesson: null };
      this.setCrumbs('Terminalis', 'Escolha o que aprender');
      $('#modprog').style.visibility = 'hidden';
      $('#lesson-foot').classList.add('hidden');
      this.renderHome();
      this.renderRail();
      $('#page').scrollTop = 0;
    }

    abrirTrilha(id) {
      const t = LX.trilhaPorId(id);
      if (!t || t.estado !== 'disponivel') return;
      this.trilhaId = id;
      try { localStorage.setItem('terminalis.trilha', id); } catch (e) { }
      const prox = this.allLessons().find(x => !Progress.lessonDone(x.lesson.id));
      if (prox) this.goLesson(prox.lesson.id);
      else this.goRoadmap();
    }

    renderHome() {
      const disp = LX.TRILHAS.filter(t => t.estado === 'disponivel');
      const plan = LX.TRILHAS.filter(t => t.estado !== 'disponivel');
      const total = this.todasAsLicoes().length;
      const feitas = this.todasAsLicoes().filter(x => Progress.lessonDone(x.lesson.id)).length;
      let html = `<div class="doc wide home">
        <div class="home-hero">
          <div class="eyebrow">Plataforma de estudo prático</div>
          <h1 class="title">O que você quer aprender hoje?</h1>
          <p class="lede">Cada trilha é escrita para ser feita no terminal ao lado — um Linux de verdade rodando no seu navegador. Você lê, executa, erra, recebe o retorno e avança.</p>
          ${feitas ? `<div class="home-cont"><span>Você já concluiu <b>${feitas}</b> de ${total} aulas.</span><button class="btn primary" id="home-continuar">Continuar de onde parei</button></div>` : ''}
        </div>
        <div class="trilha-grid">`;
      for (const t of disp) {
        const st = this.statsTrilha(t);
        html += `<button class="trilha-card c-${t.cor}" data-trilha="${t.id}">
          <span class="tc-top">
            <span class="tc-ic">${t.icone}</span>
            <span class="tc-ring" style="--p:${st.pct}"><span class="tc-pct">${st.pct}%</span></span>
          </span>
          <span class="tc-nome">${esc(t.nome)}</span>
          <span class="tc-resumo">${esc(t.resumo)}</span>
          <span class="tc-meta"><span>${st.mods} módulos</span><span class="dot"></span><span>${st.licoes} aulas</span><span class="dot"></span><span>${esc(t.nivel || '')}</span></span>
          <span class="tc-bar"><i style="width:${st.pct}%"></i></span>
          <span class="tc-cta">${st.feitas ? 'Continuar' : 'Começar'} ${ICON.next}</span>
        </button>`;
      }
      html += `</div>
        <div class="rm-phase" style="margin-top:38px"><span class="tag final">Em preparação</span></div>
        <p class="lede" style="font-size:14px;margin-bottom:16px">Estas trilhas ainda não existem — estão listadas para você saber para onde a plataforma vai crescer.</p>
        <div class="trilha-grid pequena">`;
      for (const t of plan) {
        html += `<div class="trilha-card planejado c-${t.cor}">
          <span class="tc-top"><span class="tc-ic">${t.icone}</span><span class="tc-tag">em breve</span></span>
          <span class="tc-nome">${esc(t.nome)}</span>
          <span class="tc-resumo">${esc(t.resumo)}</span>
        </div>`;
      }
      html += `</div></div>`;
      $('#page').innerHTML = html;
      $$('[data-trilha]').forEach(b => b.onclick = () => this.abrirTrilha(b.dataset.trilha));
      const cont = $('#home-continuar');
      if (cont) cont.onclick = () => {
        const last = Progress.data.lastLesson;
        if (last && this.findLesson(last)) {
          this.trilhaId = (LX.trilhaDe(this.findLesson(last).mod.id) || {}).id || this.trilhaId;
          this.goLesson(last);
        } else {
          const prox = this.todasAsLicoes().find(x => !Progress.lessonDone(x.lesson.id));
          if (prox) { this.trilhaId = (LX.trilhaDe(prox.mod.id) || {}).id; this.goLesson(prox.lesson.id); }
        }
      };
    }

    goRoadmap() {
      this.route = { view: 'home', mod: null, lesson: null };
      this.trilhaId = null;
      this.setCrumbs('Terminalis', 'Trilha completa');
      $('#modprog').style.visibility = 'hidden';
      $('#lesson-foot').classList.add('hidden');
      this.renderRoadmap();
      this.renderRail();
      $('#page').scrollTop = 0;
    }

    goPage(name) {
      this.route = { view: 'page:' + name, mod: null, lesson: null };
      $('#modprog').style.visibility = 'hidden';
      $('#lesson-foot').classList.add('hidden');
      if (name === 'ajuda') { this.setCrumbs('Terminalis', 'Como usar a plataforma'); this.renderHelp(); }
      $('#page').scrollTop = 0;
      this.renderRail();
    }

    goLesson(id) {
      const found = this.findLesson(id);
      if (!found) return this.goRoadmap();
      const tr = LX.trilhaDe(found.mod.id);
      if (tr) { this.trilhaId = tr.id; try { localStorage.setItem('terminalis.trilha', tr.id); } catch (e) { } }
      this.route = { view: 'lesson', mod: found.mod.id, lesson: id };
      this.openMods.add(found.mod.id);
      Progress.data.lastLesson = id;
      Progress.save();
      this.setCrumbs(found.mod.group, found.mod.title);
      const done = found.mod.lessons.filter(l => Progress.lessonDone(l.id)).length;
      const pct = Math.round(done / found.mod.lessons.length * 100);
      $('#modprog').style.visibility = 'visible';
      $('#modprog-bar').style.width = pct + '%';
      $('#modprog-pct').textContent = pct + '%';
      $('#lesson-foot').classList.remove('hidden');
      this.renderLesson(found.mod, found.lesson);
      this.renderRail();
      this.applyLessonSetup();
      $('#page').scrollTop = 0;
      if ($('.sp-tab[aria-selected="true"]').dataset.tab === 'notes') this.switchTab('notes');
    }

    applyLessonSetup() {
      const f = this.findLesson(this.route.lesson);
      if (!f || !f.lesson.setup) return;
      try { f.lesson.setup(this.machine, this.term); } catch (e) { console.warn('setup falhou', e); }
    }

    /* ----------------------------- render de aula ----------------------------- */
    renderLesson(mod, lesson) {
      const idx = this.lessonIndex(lesson.id);
      const all = this.allLessons();
      const prev = idx > 0 ? all[idx - 1] : null;
      const next = idx < all.length - 1 ? all[idx + 1] : null;

      let html = `<div class="doc">
        <div class="doc-top">
          <div class="eyebrow">Aula ${esc(lesson.n)}</div>
          <div class="doc-tools">
            <button class="icon-btn" id="btn-copy-link" title="Copiar referência da aula">${ICON.link}</button>
          </div>
        </div>
        <h1 class="title">${esc(lesson.title)}</h1>`;
      if (lesson.goal) html += `<p class="lede">${lesson.goal}</p>`;
      html += LX.renderBlocks(lesson.body || [], this);
      for (const t of (lesson.tasks || [])) html += this.renderTask(t);
      html += `</div>`;
      $('#page').innerHTML = html;

      // rodapé
      const foot = $('#lesson-foot');
      const doneNow = Progress.lessonDone(lesson.id);
      foot.innerHTML =
        `<button class="nav-btn" id="nav-prev" ${prev ? '' : 'disabled'}>${ICON.prev}<span>Aula anterior</span></button>
         <div class="spacer"></div>
         <button class="nav-btn ${doneNow ? '' : 'ready'}" id="nav-done">${doneNow ? '✓ Aula concluída' : 'Marcar como concluída'}</button>
         <button class="nav-btn next ready" id="nav-next" ${next ? '' : 'disabled'}><span>Próxima aula</span>${ICON.next}</button>`;
      $('#nav-prev').onclick = () => prev && this.goLesson(prev.lesson.id);
      $('#nav-next').onclick = () => {
        if (!Progress.lessonDone(lesson.id)) Progress.markLesson(lesson.id, true);
        next && this.goLesson(next.lesson.id);
      };
      $('#nav-done').onclick = () => {
        Progress.markLesson(lesson.id, !Progress.lessonDone(lesson.id));
        this.renderRail();
        this.goLesson(lesson.id);
      };
      const cl = $('#btn-copy-link');
      if (cl) cl.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(`Terminalis — aula ${lesson.n}: ${lesson.title}`); this.toast('Referência copiada'); };

      this.wireDoc();
    }

    wireDoc() {
      $$('.code-btn[data-run]').forEach(b => b.onclick = async () => {
        this.switchTab('term');
        document.body.classList.add('show-term');
        $$('.mobile-tabs button').forEach(x => x.setAttribute('aria-pressed', String(x.dataset.m === 'term')));
        const cmds = b.dataset.run.split('\n').filter(Boolean);
        for (const c of cmds) await this.term.runVisible(c);
      });
      $$('.code-btn[data-copy]').forEach(b => b.onclick = () => {
        const pre = b.closest('.code').querySelector('pre');
        const text = Array.from(pre.querySelectorAll('.cmdline')).map(x => x.dataset.cmd).join('\n') || pre.textContent;
        if (navigator.clipboard) navigator.clipboard.writeText(text);
        this.toast('Copiado');
      });
      $$('[data-task]').forEach(el => this.wireTask(el));
    }

    /* ----------------------------- tarefas ----------------------------- */
    renderTask(t) {
      const done = Progress.taskDone(t.id);
      const kindLabel = { guiado: 'Exercício guiado', desafio: 'Desafio', avancado: 'Desafio avançado', quiz: 'Conceito', erro: 'Encontre o erro', prever: 'Preveja o resultado', trouble: 'Investigação' }[t.kind] || t.kind;
      const kindClass = ['guiado', 'desafio', 'avancado', 'quiz'].includes(t.kind) ? t.kind : (t.kind === 'trouble' || t.kind === 'erro' ? 'avancado' : 'quiz');
      let inner = `<div class="task ${done ? 'done' : ''}" data-task="${t.id}">
        <div class="task-head">
          <span class="task-kind ${kindClass}">${esc(kindLabel)}</span>
          <span class="task-state ${done ? 'ok' : ''}">${done ? '✓ concluído' : ''}</span>
        </div>
        <div class="task-title">${esc(t.title)}</div>
        <div class="task-body">${LX.renderBlocks(t.body || [], this)}</div>`;

      if (t.kind === 'quiz') {
        inner += `<div class="task-body quiz-opts">`;
        t.options.forEach((o, i) => {
          inner += `<div class="opt"><button data-opt="${i}"><span class="k">${'ABCDE'[i]}</span><span>${o.text}</span></button></div>`;
        });
        inner += `</div><div class="explain hidden"></div>`;
      } else if (t.kind === 'fill') {
        inner += `<div class="task-body"><div class="fill">${(t.template || '').split('___').map((p, i, a) =>
          `<span class="fixed">${esc(p)}</span>` + (i < a.length - 1 ? `<input type="text" data-blank="${i}" spellcheck="false" autocomplete="off">` : '')).join('')}</div></div>`;
      }

      if (t.hints && t.hints.length) {
        inner += `<div class="hints" id="hints-${t.id}"></div>`;
      }
      inner += `<div class="verdict hidden"></div>`;
      inner += `<div class="task-foot">`;
      if (t.hints && t.hints.length) {
        t.hints.forEach((h, i) => inner += `<button class="btn ghost small" data-hint="${i}">${ICON.bulb}Dica ${i + 1}</button>`);
      }
      if (t.solution) inner += `<button class="btn ghost small" data-solution>${ICON.eye}Ver solução</button>`;
      if (t.check || t.kind === 'fill') inner += `<button class="btn primary" data-verify>${ICON.verify}Verificar desafio</button>`;
      inner += `</div></div>`;
      return inner;
    }

    wireTask(el) {
      const id = el.dataset.task;
      const t = this.taskById(id);
      if (!t) return;
      const verdict = $('.verdict', el);
      const hintsBox = $('.hints', el);

      $$('[data-hint]', el).forEach(b => b.onclick = () => {
        const i = +b.dataset.hint;
        if ($(`[data-hint-shown="${i}"]`, hintsBox)) return;
        const d = document.createElement('div');
        d.className = 'hint';
        d.dataset.hintShown = String(i);
        d.innerHTML = `<span class="hl">Dica ${i + 1}</span>${t.hints[i]}`;
        hintsBox.appendChild(d);
        b.disabled = true;
      });
      const sol = $('[data-solution]', el);
      if (sol) sol.onclick = () => {
        if ($('.hint.solution', hintsBox)) return;
        const d = document.createElement('div');
        d.className = 'hint solution';
        d.innerHTML = `<span class="hl">Solução</span>${t.solution}`;
        (hintsBox || el).appendChild(d);
        sol.disabled = true;
      };

      $$('[data-opt]', el).forEach(b => b.onclick = () => {
        if (el.dataset.answered) return;
        el.dataset.answered = '1';
        const i = +b.dataset.opt;
        const opt = t.options[i];
        $$('[data-opt]', el).forEach((x, j) => {
          if (t.options[j].correct) x.classList.add('right');
          else if (j === i) x.classList.add('wrong');
          x.disabled = true;
        });
        const ex = $('.explain', el);
        ex.classList.remove('hidden');
        ex.innerHTML = opt.correct
          ? `<strong style="color:var(--green)">Correto.</strong> ${t.explain || opt.why || ''}`
          : `<strong style="color:var(--red)">Não é essa.</strong> ${opt.why || t.explain || ''}`;
        if (opt.correct) this.completeTask(t, el);
      });

      const vb = $('[data-verify]', el);
      if (vb) vb.onclick = async () => {
        vb.disabled = true;
        vb.textContent = 'Verificando…';
        try {
          let res;
          if (t.kind === 'fill') {
            const vals = $$('[data-blank]', el).map(i => i.value.trim());
            res = t.check ? await t.check({ vals, app: this, machine: this.machine, term: this.term, sh: this.term.sh })
              : { ok: vals.every((v, i) => new RegExp('^(?:' + t.answers[i] + ')$').test(v)), msg: 'Compare com a sintaxe apresentada na aula.' };
          } else {
            res = await t.check({ app: this, machine: this.machine, term: this.term, sh: this.term.sh, run: (c) => this.term.runQuiet(c) });
          }
          verdict.classList.remove('hidden', 'ok', 'fail');
          if (res.ok) {
            verdict.classList.add('ok');
            verdict.textContent = '✅ ' + (res.msg || 'Desafio concluído!');
            this.completeTask(t, el);
          } else {
            verdict.classList.add('fail');
            verdict.textContent = '❌ Ainda não. ' + (res.msg || 'Confira o enunciado e tente de novo.');
          }
        } catch (e) {
          verdict.classList.remove('hidden', 'ok');
          verdict.classList.add('fail');
          verdict.textContent = '❌ Não consegui verificar: ' + e.message;
        }
        vb.disabled = false;
        vb.innerHTML = ICON.verify + 'Verificar desafio';
      };
    }

    taskById(id) {
      for (const { lesson } of this.allLessons()) {
        for (const t of (lesson.tasks || [])) if (t.id === id) return t;
      }
      for (const p of (this.course.pages || [])) for (const t of (p.tasks || [])) if (t.id === id) return t;
      return null;
    }

    completeTask(t, el) {
      const fresh = Progress.markTask(t.id);
      el.classList.add('done');
      const st = $('.task-state', el);
      st.classList.add('ok');
      st.textContent = '✓ concluído';
      if (fresh) {
        this.toast('Desafio concluído');
        this.renderRail();
      }
      // aula completa se todos os desafios verificáveis foram feitos
      const f = this.findLesson(this.route.lesson);
      if (f) {
        const req = (f.lesson.tasks || []).filter(x => x.check || x.kind === 'quiz');
        if (req.length && req.every(x => Progress.taskDone(x.id)) && !Progress.lessonDone(f.lesson.id)) {
          Progress.markLesson(f.lesson.id, true);
          this.renderRail();
          const btn = $('#nav-done');
          if (btn) { btn.textContent = '✓ Aula concluída'; btn.classList.remove('ready'); }
        }
      }
    }

    onCommandRun() {
      if ($('.sp-tab[aria-selected="true"]').dataset.tab === 'files') this.renderFiles();
    }

    /* ----------------------------- navegador de arquivos ----------------------------- */
    renderFiles(path) {
      const sh = this.term.sh;
      this.fbPath = path || this.fbPath || sh.cwd;
      let node;
      try { node = sh.m.fs.stat(this.fbPath, sh.fsopts()); }
      catch (e) { this.fbPath = '/'; node = sh.m.fs.root; }
      const parts = this.fbPath.split('/').filter(Boolean);
      let crumbs = `<button data-go="/">/</button>`;
      let acc = '';
      parts.forEach((p, i) => { acc += '/' + p; crumbs += `<span class="sep">/</span><button data-go="${esc(acc)}">${esc(p)}</button>`; });
      let rows = '';
      let names = [];
      try { names = sh.m.fs.readdir(this.fbPath, sh.fsopts()); } catch (e) { rows = `<div class="fb-empty">Sem permissão de leitura neste diretório.</div>`; }
      const entries = names.map(n => {
        let st; try { st = sh.m.fs.lstat(LX.FileSystem.join(this.fbPath, n), sh.fsopts()); } catch (e) { st = null; }
        return { n, st };
      }).filter(e => e.st);
      entries.sort((a, b) => (b.st.type === 'dir') - (a.st.type === 'dir') || a.n.localeCompare(b.n));
      if (this.fbPath !== '/') rows += `<div class="fb-row dir" data-dir="${esc(LX.FileSystem.dirname(this.fbPath))}"><span class="ic">${ICON.folder}</span><span class="nm">..</span><span class="mode"></span><span class="sz"></span></div>`;
      for (const e of entries) {
        const isDir = e.st.type === 'dir';
        const isExe = !isDir && (e.st.mode & 0o111);
        const cls = isDir ? 'dir' : (isExe ? 'exe' : '');
        const ic = isDir ? ICON.folder : (e.st.type === 'link' ? ICON.link : ICON.file);
        rows += `<div class="fb-row ${cls}" data-${isDir ? 'dir' : 'file'}="${esc(LX.FileSystem.join(this.fbPath, e.n))}">
          <span class="ic">${ic}</span>
          <span class="nm">${esc(e.n)}${isDir ? '/' : ''}</span>
          <span class="mode">${LX.modeToRwx(e.st.mode, e.st.type)}</span>
          <span class="sz">${isDir ? '—' : LX.humanSize(e.st.size)}</span>
        </div>`;
      }
      if (!rows) rows = `<div class="fb-empty">Diretório vazio.</div>`;
      $('#fb-crumbs').innerHTML = crumbs;
      $('#fb-list').innerHTML = rows;
      $$('#fb-crumbs button').forEach(b => b.onclick = () => this.renderFiles(b.dataset.go));
      $$('#fb-list .fb-row').forEach(r => r.onclick = () => {
        if (r.dataset.dir !== undefined) this.renderFiles(r.dataset.dir);
        else this.previewFile(r.dataset.file);
      });
      $('#fb-here').onclick = () => this.renderFiles(this.term.sh.cwd);
    }

    previewFile(path) {
      const sh = this.term.sh;
      let content;
      try { content = sh.m.fs.readFile(path, sh.fsopts()); }
      catch (e) { content = `(não foi possível ler: ${e.message})`; }
      if (content.length > 20000) content = content.slice(0, 20000) + '\n… (truncado)';
      $('#fb-preview').classList.remove('hidden');
      $('#fb-prev-name').textContent = path;
      $('#fb-prev-body').textContent = content || '(arquivo vazio)';
      $('#fb-prev-close').onclick = () => $('#fb-preview').classList.add('hidden');
      $('#fb-prev-edit').onclick = async () => { await this.term.editor(path); this.previewFile(path); };
    }

    /* ----------------------------- roadmap ----------------------------- */
    renderRoadmap() {
      const st = this.stats();
      const tr = this.trilha();
      let html = `<div class="doc wide">
        <div class="eyebrow">Trilha de aprendizado</div>
        <h1 class="title">${esc(tr ? tr.nome : 'Do primeiro comando ao servidor em produção')}</h1>
        <p class="lede">${esc(tr && tr.detalhe ? tr.detalhe : 'Uma sequência única: cada módulo assume o anterior. Você lê, pratica no terminal ao lado e só avança depois de resolver.')}</p>
        <div class="stat-grid">
          <div class="stat"><div class="v">${st.pct}%</div><div class="l">Progresso</div></div>
          <div class="stat"><div class="v">${st.done}<span style="color:var(--tx-3);font-size:16px">/${st.total}</span></div><div class="l">Aulas</div></div>
          <div class="stat"><div class="v">${st.tasks}<span style="color:var(--tx-3);font-size:16px">/${st.totalTasks}</span></div><div class="l">Desafios</div></div>
          <div class="stat"><div class="v">${st.modsDone}<span style="color:var(--tx-3);font-size:16px">/${st.totalMods}</span></div><div class="l">Módulos</div></div>
        </div>`;

      let lastGroup = null;
      let firstIncomplete = true;
      for (const m of this.modulosDaTrilha()) {
        if (m.group !== lastGroup) {
          if (lastGroup !== null) html += `</div>`;
          const tag = m.group.toLowerCase().includes('docker') ? 'docker' : (m.group.toLowerCase().includes('final') || m.group.toLowerCase().includes('projet') ? 'final' : 'linux');
          html += `<div class="rm-phase"><span class="tag ${tag}">${esc(m.group)}</span></div><div class="rm-track">`;
          lastGroup = m.group;
        }
        const done = m.lessons.filter(l => Progress.lessonDone(l.id)).length;
        const complete = done === m.lessons.length && m.lessons.length > 0;
        if (!m.lessons.length) { html += `<div class="rm-node"><button class="rm-card" data-mod="${m.id}" disabled style="opacity:.5;cursor:default"><span class="n">${esc(m.num)}</span><span><span class="t">${esc(m.title)}</span><span class="d">${esc(m.blurb || '')}</span></span><span class="pg">em breve</span></button></div>`; continue; }
        let cls = complete ? 'done' : '';
        if (!complete && firstIncomplete) { cls = 'current'; firstIncomplete = false; }
        html += `<div class="rm-node ${cls}">
          <button class="rm-card" data-mod="${m.id}">
            <span class="n">${esc(m.num)}</span>
            <span><span class="t">${esc(m.title)}</span><span class="d">${esc(m.blurb || '')}</span></span>
            <span class="pg ${complete ? 'full' : ''}">${m.lessons.length ? done + '/' + m.lessons.length : 'em breve'}</span>
          </button></div>`;
      }
      if (lastGroup !== null) html += `</div>`;
      html += `</div>`;
      $('#page').innerHTML = html;
      $$('.rm-card').forEach(b => b.onclick = () => {
        const m = this.course.modules.find(x => x.id === b.dataset.mod);
        if (m && m.lessons.length) {
          const nextL = m.lessons.find(l => !Progress.lessonDone(l.id)) || m.lessons[0];
          this.goLesson(nextL.id);
        }
      });
    }

    renderHelp() {
      $('#page').innerHTML = `<div class="doc">
        <div class="eyebrow">Guia rápido</div>
        <h1 class="title">Como usar esta plataforma</h1>
        <p class="lede">O terminal à direita é um Linux de verdade rodando no seu navegador: sistema de arquivos, permissões, processos, serviços, rede e Docker. O que você cria, existe.</p>
        <h2>O ciclo</h2>
        <p>Cada aula segue o mesmo caminho: você <strong>lê</strong> a explicação, <strong>testa</strong> os exemplos no terminal, resolve o <strong>exercício guiado</strong> (que mostra o caminho), enfrenta o <strong>desafio</strong> (que não mostra) e, se quiser apertar, o <strong>desafio avançado</strong>.</p>
        <p>Quando você clica em <em>Verificar desafio</em>, a plataforma não olha o que você digitou: ela inspeciona o <strong>estado real da máquina</strong> — se o diretório existe, se a permissão está certa, se o serviço subiu. Existem muitos caminhos para o mesmo resultado, e todos valem.</p>
        <h2>Teclas do terminal</h2>
        <div class="cheat">
          <div class="cheat-row"><code>Tab</code><span>Completa comandos e caminhos</span></div>
          <div class="cheat-row"><code>↑ / ↓</code><span>Navega pelo histórico</span></div>
          <div class="cheat-row"><code>Ctrl+C</code><span>Interrompe o comando em execução</span></div>
          <div class="cheat-row"><code>Ctrl+L</code><span>Limpa a tela</span></div>
          <div class="cheat-row"><code>Ctrl+A / Ctrl+E</code><span>Início / fim da linha</span></div>
          <div class="cheat-row"><code>Ctrl+U / Ctrl+K</code><span>Apaga até o início / fim da linha</span></div>
          <div class="cheat-row"><code>Ctrl+W</code><span>Apaga a palavra anterior</span></div>
          <div class="cheat-row"><code>Ctrl+D</code><span>Sai de uma sessão aninhada (ssh, container)</span></div>
        </div>
        <h2>Editar arquivos</h2>
        <p>Use <code>nano arquivo.sh</code> para abrir o editor em tela cheia. <span class="kbd">Ctrl+S</span> grava, <span class="kbd">Ctrl+X</span> grava e sai, <span class="kbd">Esc</span> sai sem gravar. Também funciona <code>cat &gt; arquivo &lt;&lt; 'EOF'</code>.</p>
        <h2>Se você quebrar tudo</h2>
        <p>Ótimo — quebrar é parte do aprendizado. O botão <em>Resetar terminal</em>, no topo do painel, recria a máquina do zero. Seu progresso nas aulas não é perdido.</p>
        <div class="box note"><div class="box-label">Onde fica salvo</div><p>Seu progresso, suas anotações e o tempo de estudo ficam no seu navegador (localStorage). Nada é enviado para lugar nenhum.</p></div>
      </div>`;
    }
  }

  LX.App = App;
})();
