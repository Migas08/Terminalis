/* =========================================================================
   TERMINALIS — contas de estudo e sincronização de progresso
   Cada aluno tem um perfil local com uma "chave de sincronização".
   Com a chave, o progresso é gravado na nuvem do artifact e pode ser
   recuperado em qualquer outro dispositivo ou conta.
   ========================================================================= */
'use strict';
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const LS_CONTAS = 'terminalis.contas.v1';
  const LS_PROG = (id) => 'terminalis.progresso.' + id;

  const VAZIO = () => ({ lessons: {}, tasks: {}, notes: {}, seconds: 0, lastLesson: null, streakDays: [], atualizadoEm: 0 });

  /* chave legível e sem ambiguidade (sem 0/O, 1/l) */
  const ALFA = '23456789abcdefghjkmnpqrstuvwxyz';
  function novaChave() {
    let s = '';
    const buf = new Uint8Array(16);
    (self.crypto || window.crypto).getRandomValues(buf);
    for (let i = 0; i < 16; i++) s += ALFA[buf[i] % ALFA.length];
    return s.slice(0, 4) + '-' + s.slice(4, 8) + '-' + s.slice(8, 12) + '-' + s.slice(12, 16);
  }
  const chaveLimpa = (k) => String(k || '').toLowerCase().replace(/[^a-z0-9]/g, '');

  /* --------------------------- fusão de progresso --------------------------- */
  function fundir(a, b) {
    a = a || VAZIO(); b = b || VAZIO();
    const r = VAZIO();
    r.lessons = Object.assign({}, a.lessons, b.lessons);
    r.tasks = Object.assign({}, a.tasks, b.tasks);
    // as notas mais recentes vencem, por chave
    r.notes = Object.assign({}, a.notes, b.notes);
    if ((a.atualizadoEm || 0) > (b.atualizadoEm || 0)) r.notes = Object.assign({}, b.notes, a.notes);
    r.seconds = Math.max(a.seconds || 0, b.seconds || 0);
    r.lastLesson = (a.atualizadoEm || 0) >= (b.atualizadoEm || 0) ? (a.lastLesson || b.lastLesson) : (b.lastLesson || a.lastLesson);
    r.streakDays = Array.from(new Set([].concat(a.streakDays || [], b.streakDays || []))).sort();
    r.atualizadoEm = Math.max(a.atualizadoEm || 0, b.atualizadoEm || 0);
    return r;
  }

  /* ================================ Contas ================================ */
  const Contas = {
    perfis: [],
    ativoId: null,
    db: null,
    estado: 'local',        // local | sincronizando | sincronizado | erro
    app: null,
    _timer: null,
    _unsub: null,

    /* ---------- persistência local ---------- */
    carregarLocal() {
      try {
        const raw = localStorage.getItem(LS_CONTAS);
        if (raw) {
          const d = JSON.parse(raw);
          this.perfis = Array.isArray(d.perfis) ? d.perfis : [];
          this.ativoId = d.ativo || (this.perfis[0] && this.perfis[0].id) || null;
        }
      } catch (e) { }
      if (!this.perfis.length) {
        // migra o progresso da versão sem contas, se existir
        let antigo = null;
        try { const v = localStorage.getItem('terminalis.v1'); if (v) antigo = JSON.parse(v); } catch (e) { }
        const p = this.novoPerfil('Aluno', antigo);
        this.ativoId = p.id;
      }
      return this.ativo();
    },
    salvarLocal() {
      try {
        localStorage.setItem(LS_CONTAS, JSON.stringify({ perfis: this.perfis, ativo: this.ativoId }));
      } catch (e) { }
    },
    ativo() { return this.perfis.find(p => p.id === this.ativoId) || this.perfis[0] || null; },

    novoPerfil(nome, progressoInicial) {
      const p = {
        id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        nome: nome || 'Aluno',
        chave: novaChave(),
        criadoEm: Date.now()
      };
      this.perfis.push(p);
      const prog = progressoInicial ? fundir(VAZIO(), progressoInicial) : VAZIO();
      prog.atualizadoEm = Date.now();
      this.gravarProgresso(p.id, prog);
      this.salvarLocal();
      return p;
    },

    lerProgresso(id) {
      try {
        const raw = localStorage.getItem(LS_PROG(id));
        if (raw) return Object.assign(VAZIO(), JSON.parse(raw));
      } catch (e) { }
      return VAZIO();
    },
    gravarProgresso(id, dados) {
      try { localStorage.setItem(LS_PROG(id), JSON.stringify(dados)); } catch (e) { }
    },

    /* ---------- nuvem ---------- */
    async conectar() {
      if (!window.claude || !window.claude.use) return;
      let db = null;
      try { db = await window.claude.use('db'); } catch (e) { db = null; }
      if (!db) { this.estado = 'local'; this.pintarEstado(); return; }
      this.db = db;
      await this.puxar();
      this.escutar();
    },

    ref(chave) {
      if (!this.db) return null;
      const k = chaveLimpa(chave);
      if (!k) return null;
      try { return this.db.doc('alunos/' + k); } catch (e) { return null; }
    },

    /* traz o que está na nuvem e funde com o local */
    async puxar() {
      const p = this.ativo();
      const ref = p && this.ref(p.chave);
      if (!ref) return;
      this.estado = 'sincronizando'; this.pintarEstado();
      try {
        const snap = await ref.get();
        if (snap.exists) {
          const remoto = snap.data() || {};
          if (remoto.nome && remoto.nome !== p.nome) { p.nome = remoto.nome; this.salvarLocal(); }
          const fundido = fundir(this.lerProgresso(p.id), remoto.progresso || {});
          this.gravarProgresso(p.id, fundido);
          if (this.app) this.app.recarregarProgresso(fundido);
        }
        this.estado = 'sincronizado';
      } catch (e) {
        this.estado = e && e.code === 'not_granted' ? 'local' : 'erro';
      }
      this.pintarEstado();
    },

    /* mantém a página atualizada se você estudar em outro dispositivo */
    escutar() {
      if (this._unsub) { try { this._unsub(); } catch (e) { } this._unsub = null; }
      const p = this.ativo();
      const ref = p && this.ref(p.chave);
      if (!ref) return;
      try {
        this._unsub = ref.onSnapshot((snap) => {
          if (!snap.exists) return;
          const remoto = snap.data() || {};
          if (snap.metadata && snap.metadata.hasPendingWrites) return;
          const local = this.lerProgresso(p.id);
          if ((remoto.progresso && remoto.progresso.atualizadoEm || 0) <= (local.atualizadoEm || 0)) return;
          const fundido = fundir(local, remoto.progresso || {});
          this.gravarProgresso(p.id, fundido);
          if (this.app) { this.app.recarregarProgresso(fundido); this.app.toast('Progresso atualizado de outro dispositivo'); }
        }, () => { this.estado = 'erro'; this.pintarEstado(); });
      } catch (e) { }
    },

    /* envia (com atraso, para não escrever a cada clique) */
    agendarEnvio(dados) {
      clearTimeout(this._timer);
      this._timer = setTimeout(() => this.enviar(dados), 1200);
    },
    async enviar(dados) {
      const p = this.ativo();
      if (!p) return;
      this.gravarProgresso(p.id, dados);
      const ref = this.ref(p.chave);
      if (!ref) return;
      this.estado = 'sincronizando'; this.pintarEstado();
      try {
        await ref.set({ nome: p.nome, progresso: dados, atualizadoEm: Date.now() });
        this.estado = 'sincronizado';
      } catch (e) {
        this.estado = e && (e.code === 'not_granted' || e.code === 'capability_disabled') ? 'local' : 'erro';
      }
      this.pintarEstado();
    },

    /* ---------- ações de conta ---------- */
    trocar(id) {
      if (!this.perfis.find(p => p.id === id)) return;
      this.ativoId = id;
      this.salvarLocal();
      if (this.app) this.app.recarregarProgresso(this.lerProgresso(id));
      this.puxar().then(() => this.escutar());
      this.pintar();
    },
    criar(nome) {
      const p = this.novoPerfil(nome);
      this.trocar(p.id);
      return p;
    },
    renomear(id, nome) {
      const p = this.perfis.find(x => x.id === id);
      if (!p) return;
      p.nome = nome;
      this.salvarLocal();
      this.pintar();
      if (id === this.ativoId) this.agendarEnvio(this.lerProgresso(id));
    },
    remover(id) {
      if (this.perfis.length <= 1) return false;
      this.perfis = this.perfis.filter(p => p.id !== id);
      try { localStorage.removeItem(LS_PROG(id)); } catch (e) { }
      if (this.ativoId === id) this.ativoId = this.perfis[0].id;
      this.salvarLocal();
      this.trocar(this.ativoId);
      return true;
    },

    /* entra com uma chave vinda de outro dispositivo/conta */
    async entrarComChave(chaveBruta, nomeSugerido) {
      const k = chaveLimpa(chaveBruta);
      if (k.length < 12) return { ok: false, msg: 'Chave inválida — ela tem 16 caracteres.' };
      const jaTem = this.perfis.find(p => chaveLimpa(p.chave) === k);
      if (jaTem) { this.trocar(jaTem.id); return { ok: true, msg: 'Esse perfil já estava aqui. Ativei ele.' }; }
      if (!this.db) return { ok: false, msg: 'A sincronização não está disponível nesta visualização. Use "exportar/importar progresso".' };
      let snap;
      try { snap = await this.ref(k).get(); }
      catch (e) { return { ok: false, msg: 'Não consegui consultar a nuvem agora. Tente de novo.' }; }
      if (!snap.exists) return { ok: false, msg: 'Nenhum progresso encontrado para essa chave.' };
      const d = snap.data() || {};
      const fmt = k.slice(0, 4) + '-' + k.slice(4, 8) + '-' + k.slice(8, 12) + '-' + k.slice(12, 16);
      const p = {
        id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        nome: d.nome || nomeSugerido || 'Aluno', chave: fmt, criadoEm: Date.now()
      };
      this.perfis.push(p);
      this.gravarProgresso(p.id, fundir(VAZIO(), d.progresso || {}));
      this.salvarLocal();
      this.trocar(p.id);
      return { ok: true, msg: `Progresso de "${p.nome}" restaurado.` };
    },

    /* ---------- exportar / importar sem nuvem ---------- */
    exportar() {
      const p = this.ativo();
      const payload = { v: 1, nome: p.nome, chave: p.chave, progresso: this.lerProgresso(p.id) };
      return btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
    },
    importar(texto) {
      let d;
      try { d = JSON.parse(decodeURIComponent(escape(atob(String(texto).trim())))); }
      catch (e) { return { ok: false, msg: 'Código inválido. Cole o texto completo que foi gerado na exportação.' }; }
      if (!d || !d.progresso) return { ok: false, msg: 'Código sem dados de progresso.' };
      const existente = this.perfis.find(x => chaveLimpa(x.chave) === chaveLimpa(d.chave));
      if (existente) {
        const fundido = fundir(this.lerProgresso(existente.id), d.progresso);
        this.gravarProgresso(existente.id, fundido);
        this.trocar(existente.id);
        return { ok: true, msg: 'Progresso fundido com o perfil que já existia aqui.' };
      }
      const p = {
        id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        nome: d.nome || 'Aluno', chave: d.chave || novaChave(), criadoEm: Date.now()
      };
      this.perfis.push(p);
      this.gravarProgresso(p.id, fundir(VAZIO(), d.progresso));
      this.salvarLocal();
      this.trocar(p.id);
      return { ok: true, msg: `Perfil "${p.nome}" importado.` };
    },

    /* ================================ interface ================================ */
    inicial(nome) { return (String(nome || '?').trim()[0] || '?').toUpperCase(); },

    pintar() {
      const p = this.ativo();
      if (!p) return;
      const chip = $('#conta-chip');
      if (chip) chip.innerHTML =
        `<span class="av">${esc(this.inicial(p.nome))}</span><span class="nm">${esc(p.nome)}</span>` +
        `<span class="cr">▾</span>`;
      this.pintarEstado();
      if ($('#conta-menu') && !$('#conta-menu').classList.contains('hidden')) this.pintarMenu();
    },

    pintarEstado() {
      const el = $('#sync-state');
      if (!el) return;
      const mapa = {
        local: ['dot-local', 'só neste navegador'],
        sincronizando: ['dot-sync', 'sincronizando…'],
        sincronizado: ['dot-ok', 'sincronizado'],
        erro: ['dot-err', 'falha ao sincronizar']
      };
      const [cls, txt] = mapa[this.estado] || mapa.local;
      el.className = 'sync-state ' + cls;
      el.title = 'Progresso: ' + txt;
      el.innerHTML = `<i></i><span>${txt}</span>`;
    },

    pintarMenu() {
      const p = this.ativo();
      const box = $('#conta-menu');
      if (!box || !p) return;
      const podeNuvem = !!this.db;
      box.innerHTML = `
        <div class="cm-head">
          <span class="av big">${esc(this.inicial(p.nome))}</span>
          <span>
            <input class="cm-nome" id="cm-nome" value="${esc(p.nome)}" maxlength="28" aria-label="Nome do perfil">
            <span class="cm-sub" id="sync-state-menu"></span>
          </span>
        </div>

        <div class="cm-sec">Perfis neste navegador</div>
        <div class="cm-list">
          ${this.perfis.map(x => `
            <button class="cm-perfil ${x.id === p.id ? 'ativo' : ''}" data-perfil="${x.id}">
              <span class="av">${esc(this.inicial(x.nome))}</span>
              <span class="pn">${esc(x.nome)}</span>
              ${x.id === p.id ? '<span class="tick">✓</span>' : ''}
            </button>`).join('')}
        </div>
        <div class="cm-row">
          <input id="cm-novo" placeholder="nome do novo perfil" maxlength="28">
          <button class="btn small" id="cm-criar">Criar</button>
        </div>

        <div class="cm-sec">Levar seu progresso para outro dispositivo</div>
        ${podeNuvem ? `
          <p class="cm-p">Sua chave de sincronização. Guarde-a: com ela você recupera este progresso em qualquer navegador ou conta.</p>
          <div class="cm-key"><code id="cm-chave">${esc(p.chave)}</code><button class="btn small ghost" id="cm-copiar">copiar</button></div>
          <div class="cm-row">
            <input id="cm-entrar" placeholder="colar chave de outro dispositivo" maxlength="24">
            <button class="btn small" id="cm-entrar-btn">Entrar</button>
          </div>
        ` : `
          <p class="cm-p">A sincronização automática não está disponível nesta visualização. Use o código abaixo para levar seu progresso manualmente.</p>
        `}

        <div class="cm-sec">Código de progresso (funciona sempre)</div>
        <div class="cm-row">
          <button class="btn small ghost" id="cm-exportar">Copiar meu código</button>
          <button class="btn small ghost" id="cm-importar-abrir">Colar um código</button>
        </div>
        <textarea id="cm-codigo" class="cm-codigo hidden" rows="3" placeholder="cole aqui o código exportado e clique em Importar"></textarea>
        <div class="cm-row hidden" id="cm-importar-row"><button class="btn small" id="cm-importar">Importar</button></div>

        ${this.perfis.length > 1 ? `<div class="cm-row"><button class="btn small ghost danger" id="cm-remover">Remover este perfil deste navegador</button></div>` : ''}
      `;

      const est = $('#sync-state-menu');
      if (est) est.textContent = { local: 'salvo só neste navegador', sincronizando: 'sincronizando…', sincronizado: 'sincronizado na nuvem', erro: 'falha ao sincronizar' }[this.estado];

      $('#cm-nome').addEventListener('change', (e) => this.renomear(p.id, e.target.value.trim() || 'Aluno'));
      $$('[data-perfil]', box).forEach(b => b.onclick = () => { this.trocar(b.dataset.perfil); this.pintarMenu(); });
      $('#cm-criar').onclick = () => {
        const nome = $('#cm-novo').value.trim();
        if (!nome) return;
        this.criar(nome);
        this.pintarMenu();
        this.app && this.app.toast('Perfil criado');
      };
      const copiar = $('#cm-copiar');
      if (copiar) copiar.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(p.chave); this.app && this.app.toast('Chave copiada'); };
      const entrarBtn = $('#cm-entrar-btn');
      if (entrarBtn) entrarBtn.onclick = async () => {
        entrarBtn.disabled = true;
        const r = await this.entrarComChave($('#cm-entrar').value);
        entrarBtn.disabled = false;
        this.app && this.app.toast(r.msg);
        if (r.ok) this.pintarMenu();
      };
      $('#cm-exportar').onclick = () => {
        const cod = this.exportar();
        const ta = $('#cm-codigo');
        ta.classList.remove('hidden');
        ta.value = cod;
        ta.select();
        navigator.clipboard && navigator.clipboard.writeText(cod);
        this.app && this.app.toast('Código copiado');
      };
      $('#cm-importar-abrir').onclick = () => {
        $('#cm-codigo').classList.remove('hidden');
        $('#cm-codigo').value = '';
        $('#cm-importar-row').classList.remove('hidden');
        $('#cm-codigo').focus();
      };
      $('#cm-importar').onclick = () => {
        const r = this.importar($('#cm-codigo').value);
        this.app && this.app.toast(r.msg);
        if (r.ok) this.pintarMenu();
      };
      const rem = $('#cm-remover');
      if (rem) rem.onclick = () => {
        if (!confirm(`Remover o perfil "${p.nome}" deste navegador? O progresso na nuvem continua acessível pela chave ${p.chave}.`)) return;
        this.remover(p.id);
        this.pintarMenu();
      };
    },

    montar(app) {
      this.app = app;
      this.carregarLocal();
      const chip = $('#conta-chip');
      const menu = $('#conta-menu');
      if (chip) {
        chip.onclick = (e) => {
          e.stopPropagation();
          const abrir = menu.classList.contains('hidden');
          menu.classList.toggle('hidden', !abrir);
          if (abrir) this.pintarMenu();
        };
        document.addEventListener('click', (e) => {
          if (menu && !menu.classList.contains('hidden') && !e.target.closest('#conta-menu') && !e.target.closest('#conta-chip'))
            menu.classList.add('hidden');
        });
      }
      this.pintar();
      // a nuvem chega depois; a página funciona sem ela
      this.conectar();
    }
  };

  LX.Contas = Contas;
  LX.fundirProgresso = fundir;
})();
